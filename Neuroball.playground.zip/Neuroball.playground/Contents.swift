//: Playground - noun: a place where people can play
// Code by Wenzheng Du - Founder of InsightfulAI
// Available on GitHub: https://github.com/InsightfulAI/neuroball
// NEUROBALL is a game where you can play against AI opponents. As you play, the game will record your movements which can be used to train an AI "personality" that mimics your behaviour.

// Whether to show the tutorial. Change to false to skip the tutorial (default true)
let tutorial: Bool = true

// Your name (default "Player")
let name: String = "Player"

// Score required to win a game (default 11)
let scoreToWin: Int = 11

// Reaction time of the "bot" AI, lower is harder (default 0.3)
let botReactionTime: Double = 0.3

// Iterations to train the neural network for. Decrease if slow (default 1000)
let nnTrainIterations: Int = 1000


// DO NOT CHANGE THIS
startGame(tutorial: tutorial, name: name, winScore: scoreToWin, reactionTime: botReactionTime, nnIter: nnTrainIterations)
