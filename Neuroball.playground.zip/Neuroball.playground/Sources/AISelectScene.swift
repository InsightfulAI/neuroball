import Foundation
import SpriteKit

public class AISelectScene: SKScene {
    
    private let startY: CGFloat = CGFloat(180)
    private let gapY: CGFloat = CGFloat(-60)
    
    private var buttons: [Button] = []
    
    public override func sceneDidLoad() {
        let button: Button = childNode(withName: "home") as! Button
        button.addAction(action: home)
        buttons.append(button)
        
        let networks: NNManager = GameData.instance.neuralNetworks
        constructButtons(networks: networks)
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t: UITouch in touches {
            for button: Button in buttons {
                _ = button.checkClick(pointer: t.location(in: self))
            }
        }
    }
    
    private func constructButtons(networks: NNManager) {
        for i in 0...(networks.models.count-1) {
            let button: Button = Button.init(texture: nil, color: UIColor(red: CGFloat(1), green: CGFloat(1), blue: CGFloat(1), alpha: CGFloat(1)), size: CGSize(width: 400, height: 50))
            addChild(button)
            button.position = CGPoint(x: 0, y: startY + (CGFloat(i) * gapY))
            button.addAction(action: {
                self.playAI(index: i)
            })
            let buttonText: SKLabelNode = SKLabelNode()
            buttonText.position = button.position
            buttonText.text = networks.names[i]
            buttonText.verticalAlignmentMode = .center
            buttonText.fontColor = UIColor.black
            addChild(buttonText)
            buttons.append(button)
        }
    }
    
    private func home() {
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = HomeScene(fileNamed: "HomeScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
    
    private func playAI(index i: Int) {
        GameData.instance.isBot = false
        GameData.instance.aiModel = GameData.instance.neuralNetworks.models[i]
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = GameScene(fileNamed: "GameScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
}
