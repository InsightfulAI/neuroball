import Foundation
import CoreGraphics
import SpriteKit

public class Ball: SKSpriteNode {
    
    public let ballSize = 20.0
    public let ballCollisionSize = 10.0
    public let launchImpulse = 5
    public let maxVelocity: CGFloat = CGFloat(1200)
    public let maxAngularVelocity: CGFloat = CGFloat(20)
    
    var phys: SKPhysicsBody
    
    public override init(texture tex: SKTexture!, color colour: UIColor, size s: CGSize) {
        //creates physics
        let cgBallSize = CGFloat(ballSize)
        phys = SKPhysicsBody(circleOfRadius: CGFloat(ballCollisionSize))
        
        super.init(texture: tex, color: colour, size: s)
        
        //sets the size of the ball
        xScale = cgBallSize / frame.width
        yScale = cgBallSize / frame.height
        
        //initialises physics to predefined values
        physInit()
    }
    
    public required init?(coder decoder: NSCoder) {
        let cgBallSize = CGFloat(ballSize)
        phys = SKPhysicsBody(circleOfRadius: cgBallSize)
        super.init(coder: decoder)
    }
    
    public func physInit() {
        phys.linearDamping = CGFloat(0)
        phys.restitution = CGFloat(0.8)
        phys.friction = CGFloat(1.0)
        phys.isDynamic = true
        phys.contactTestBitMask = 1
        phys.collisionBitMask = 3
        phys.categoryBitMask = 3
        physicsBody = phys
    }
    
    public func launch() {
        // Launches in a 45 degree cone
        let angle = CGFloat.random(in: CGFloat.pi*CGFloat(0.25) ... CGFloat.pi*CGFloat(0.75))
        let cgImpulse = CGFloat(launchImpulse)
        let xImpulse = cos(angle) * cgImpulse //CGFloat(0)
        let randomBool: Bool = Bool.random()
        let randomScalar: CGFloat = randomBool ? CGFloat(-1) : CGFloat(1)
        let yImpulse = sin(angle) * randomScalar * cgImpulse
        phys.applyImpulse(CGVector(dx: xImpulse, dy: yImpulse))
    }
    
    public func spin() {
        let spinAmount: CGFloat = CGFloat(-1)
        
        //transform by 90 degrees
        let dxVel: CGFloat = phys.velocity.dx
        let dyVel: CGFloat = phys.velocity.dy
        let dxSpin: CGFloat = dyVel
        let dySpin: CGFloat = -dxVel
        
        if phys.angularVelocity > maxAngularVelocity {
            phys.angularVelocity = maxAngularVelocity
        } else if phys.angularVelocity < -maxAngularVelocity {
            phys.angularVelocity = -maxAngularVelocity
        }
        
        let spinConstant = spinAmount*phys.angularVelocity*(phys.velocity.getMagnitude()*phys.velocity.getMagnitude()/maxVelocity/maxVelocity)
        
        let spinVec: CGVector = CGVector(dx: dxSpin, dy: dySpin).getNormalised()*spinConstant
        
        phys.applyForce(spinVec)
    }
    
    public func clampVelocity() {
        //Check for top speed
        if(phys.velocity.getMagnitude() > maxVelocity) {
            phys.velocity = phys.velocity.getNormalised()*maxVelocity
        }
    }
    
}
