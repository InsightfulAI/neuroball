import Foundation
import CoreGraphics

public class BasicAIController: Controller {
    
    let baselineY: CGFloat = CGFloat(-280)
    let volleyY: CGFloat = CGFloat(-120)
    let baselineBallV: CGFloat = CGFloat(800)
    let volleyBallV: CGFloat = CGFloat(100)
    let stopMovingRadius: CGFloat = CGFloat(6)
    
    var reactionTime: Double = 0.2
    
    var lastTime: Double = Date().timeIntervalSince1970
    var currentSensor: Sensor? = nil
    
    public override init(player paddle: Paddle) {
        super.init(player: paddle)
    }
    
    public init(player paddle: Paddle, reactionTime rt: Double) {
        super.init(player: paddle)
        reactionTime = rt
    }
    
    public override func getMoveData(sensor gameSensor: Sensor) -> MoveData {
        let currentTime: Double = Date().timeIntervalSince1970
        if (currentTime >= lastTime + reactionTime) || (currentSensor == nil) {
            lastTime = currentTime
            currentSensor = gameSensor
        }
        let desiredX: CGFloat = currentSensor!.ballX
        let ballV: CGFloat = currentSensor!.ballVY
        var aggression: CGFloat = CGFloat.ilerp(min: baselineBallV, max: volleyBallV, value: ballV)
        aggression = CGFloat.clamp(min: CGFloat(0), max: CGFloat(1), value: aggression)
        let desiredY: CGFloat = CGFloat.lerp(min:baselineY, max: volleyY, alpha: aggression)
        var shouldMove: Bool = true
        let direction = CGVector(dx: desiredX - gameSensor.selfX, dy: desiredY - gameSensor.selfY)
        //print(desiredX.description + ", " + desiredY.description)
        //Prevents "jumpy" behaviour
        if direction.getMagnitude() < stopMovingRadius {
            shouldMove = false
        }
        return MoveData(direction: direction.getNormalised(), shouldMove: shouldMove, desiredMoveLocation: CGVector(dx: desiredX, dy: desiredY))
    }
    
    /*public override func control(sensor gameSensor: Sensor) {
        let currentTime = Date().timeIntervalSince1970
        if currentTime >= lastTime + reactionTime {
            //sensor.
        }
        if let cs: Sensor = currentSensor {
            super.control(sensor: cs)
        }
    }*/
    
}

public extension CGFloat {
    //Linearly interpolates between two values
    static func lerp(min minimum: CGFloat, max maximum: CGFloat, alpha a: CGFloat) -> CGFloat {
        let magnitude = maximum - minimum
        return magnitude*a + minimum
    }
    //Inverse linear interpolation
    static func ilerp(min minimum: CGFloat, max maximum: CGFloat, value v: CGFloat) -> CGFloat {
        return (v-minimum)/(maximum-minimum)
    }
    //Clamp
    static func clamp(min minimum: CGFloat, max maximum: CGFloat, value v: CGFloat) -> CGFloat {
        if v > maximum {
            return maximum
        } else if v < minimum {
            return minimum
        }
        return v
    }
}
