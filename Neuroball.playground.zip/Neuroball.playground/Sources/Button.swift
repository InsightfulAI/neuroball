import Foundation
import SpriteKit

public class Button: SKSpriteNode {
    
    public var actions: [() -> Void] = []
    
    private var disabled: Bool = false
    
    public override init(texture: SKTexture?, color: UIColor, size: CGSize) {
        super.init(texture: texture, color: color, size: size)
    }
    
    public required init?(coder decoder: NSCoder) {
        super.init(coder: decoder)
    }
    
    public func checkClick(pointer: CGPoint) -> Bool {
        if disabled {
            return false
        }
        let clicked: Bool = frame.contains(pointer)
        if (clicked) {
            for action: () -> Void in actions {
                action()
            }
        }
        return clicked
    }
    
    public func addAction(action: @escaping ()-> Void) {
        actions.append(action)
    }
    
    public func disable() {
        alpha = CGFloat(0)
        disabled = true
    }
    
    public func enable() {
        alpha = CGFloat(1)
        disabled = false
    }
    
}
