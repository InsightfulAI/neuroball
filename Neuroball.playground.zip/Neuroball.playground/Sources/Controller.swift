import Foundation
import CoreGraphics

public class Controller{
    
    let paddle: Paddle
    
    public init(player paddle: Paddle) {
        self.paddle = paddle
    }
    
    public func getMoveData(sensor gameSensor: Sensor) -> MoveData{
        //Inherited classes should override this
        return MoveData(direction: CGVector.zero, shouldMove: false, desiredMoveLocation: CGVector.zero)
    }
    
    public func control(sensor gameSensor: Sensor) {
        var moveData: MoveData = getMoveData(sensor: gameSensor)
        if(gameSensor.flippedY) {
            moveData.direction = CGVector(dx: moveData.direction.dx, dy: -moveData.direction.dy)
        }
        if (moveData.shouldMove) {
            paddle.movePaddle(direction: moveData.direction)
        } else {
            paddle.physicsBody!.velocity = CGVector.zero
        }
    }
    
}

public struct MoveData {
    
    var direction: CGVector
    var shouldMove: Bool
    var desiredMoveLocation: CGVector
}
