import Foundation
import CoreGraphics

public class DataMinibatch {
    
    public static let minibatchSize: Int = 64
    public static let numEntries: Int = 2
    public static let numLabelsMove: Int = 2
    public static let numLabelsShouldMove: Int = 1
    
    public let data: Matrix
    public let labelsMove: Matrix
    public let labelsShouldMove: Matrix
    public var index = 0
    
    public init() {
        data = Matrix.zeroes(rows: DataMinibatch.numEntries, columns: DataMinibatch.minibatchSize)
        labelsMove = Matrix.zeroes(rows: DataMinibatch.numLabelsMove, columns: DataMinibatch.minibatchSize)
        labelsShouldMove = Matrix.zeroes(rows: DataMinibatch.numLabelsShouldMove, columns: DataMinibatch.minibatchSize)
    }
    
    //Returns false if full
    public func enterData(sensor s: Sensor, moveData md: MoveData) -> Bool{
        if index >= DataMinibatch.minibatchSize {
            return false
        }
        data.setColumn(value: s.getLabelsVector(), column: index)
        /*let notMovingVelocityMultiplier: CGFloat = CGFloat(0.1) //To distinguish between when the paddle moves and doesn't move
        var velocityMultiplier: CGFloat = CGFloat(1.0)
        if !md.shouldMove {
            velocityMultiplier = notMovingVelocityMultiplier
        }
        labelsMove[0, index] = Double(md.direction.dx * velocityMultiplier)
        labelsMove[1, index] = Double(md.direction.dy * velocityMultiplier)*/
        labelsMove[0, index] = Double(md.desiredMoveLocation.dx)
        //labelsMove[0, index] = Double(s.ballX)
        labelsMove[1, index] = Double(md.desiredMoveLocation.dy)
        labelsShouldMove[0, index] = md.shouldMove ? 1 : 0
        index += 1
        return true
    }
    
}
