import Foundation
import SpriteKit
import PlaygroundSupport

//Singleton class for storing everything
public class GameData {
    
    public var logML: Bool = true
    
    public var mlData: GameMLManager = GameMLManager()
    
    public var isBot: Bool = true
    
    public var aiModel: String = "$R $W {m1; n2; [-0.035| -0.064| ]} {m1; n1; [3.14| ]} {m2; n1; [-0.30| -3.06| ]} $B {m1; n1; [0.84| ]} {m1; n1; [0.35| ]} {m2; n1; [-0.021| -0.20| ]}"
    
    public var tutorial: Bool = true
    
    public var won: Bool = true
    
    public var neuralNetworks: NNManager = NNManager()
    
    public var numModelsTrained: Int = 0
    
    public var name: String = "Player"
    
    public var winScore: Int = 11
    
    public var reactionTime: Double = 0.3
    
    public var nnIter: Int = 1000
    
    //public var mlModel: NNModel = NNModel(layerSizes: [DataMinibatch.numEntries, 10, 5, DataMinibatch.numLabelsMove], type: NNModel.NNType.regressor)
    
    public static let instance: GameData = GameData()
    
    private init() {
        
    }
    
}

public func startGame(tutorial: Bool, name: String, winScore: Int, reactionTime: Double, nnIter: Int) {
    GameData.instance.tutorial = tutorial
    GameData.instance.name = name + " NN "
    GameData.instance.winScore = winScore
    GameData.instance.reactionTime = reactionTime
    GameData.instance.nnIter = nnIter
    
    let skView = SKView(frame: CGRect(x: 0.0, y: 0.0, width: 480.0, height: 640.0))
    skView.preferredFramesPerSecond = 60
    let scene = HomeScene(fileNamed: "HomeScene.sks")
    skView.presentScene(scene)
    PlaygroundPage.current.liveView = skView
}
