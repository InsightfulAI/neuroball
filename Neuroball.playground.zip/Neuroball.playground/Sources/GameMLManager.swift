import Foundation

public class GameMLManager {
    
    var minibatches: [DataMinibatch] = [DataMinibatch()]
    
    var index = 0
    
    public func enterData(sensor s: Sensor, moveData md: MoveData) {
        let successful: Bool = minibatches[index].enterData(sensor: s, moveData: md)
        if !successful {
            minibatches.append(DataMinibatch())
            index += 1
            enterData(sensor: s, moveData: md)
        }
    }
    
}
