import Foundation
import SpriteKit

public class GameOverScene: SKScene {
    
    private let winText: String = "You Win!"
    private let loseText: String = "You Lose"
    
    private let tutorialText1: String = """
That was a hard-coded bot. Notice how it wouldn't use momentum to its advantage? Game AI had always been different to how a human would play a game. However, we can use machine learning to train neural networks to play like humans. Click \"Train NN\" to train a neural network on the game data that we gathered in the last game.
"""
    private let tutorialText2: String = """
That was something different, wasn\'t it? That neural network had learned by watching you play. With neural networks, you can train them to play with a variety of styles and skill levels. Go home and click \"Play NN\" to find out more.
"""
    
    private var buttons: [Button] = []
    
    public override func sceneDidLoad() {
        let titleText: SKLabelNode = childNode(withName: "titleText") as! SKLabelNode
        if GameData.instance.won {
            titleText.text = winText
        } else {
            titleText.text = loseText
        }
        
        let text: SKLabelNode = childNode(withName: "text") as! SKLabelNode
        text.preferredMaxLayoutWidth = CGFloat(400)
        if (GameData.instance.tutorial) {
            if (GameData.instance.isBot) {
                text.text = tutorialText1
            } else {
                text.text = tutorialText2
                GameData.instance.tutorial = false
            }
        }
        
        let trainNNButton: Button = childNode(withName: "trainNN") as! Button
        trainNNButton.addAction(action: trainNN)
        buttons.append(trainNNButton)
        
        let homeButton: Button = childNode(withName: "home") as! Button
        if (!GameData.instance.tutorial) {
            homeButton.addAction(action: home)
            buttons.append(homeButton)
        } else if GameData.instance.isBot {
            homeButton.removeFromParent()
        }

        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t: UITouch in touches {
            for button: Button in buttons {
                _ = button.checkClick(pointer: t.location(in: self))
            }
        }
    }
    
    private func trainNN() {
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = TrainNNScene(fileNamed: "TrainNNScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
    
    private func home() {
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = HomeScene(fileNamed: "HomeScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
}
