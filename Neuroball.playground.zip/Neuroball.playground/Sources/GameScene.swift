import Foundation
import SpriteKit

public class GameScene: SKScene, SKPhysicsContactDelegate {
    
    var lastUpdateTimeInterval: CFTimeInterval?
    
    var scoreToWin: Int = 11
    
    var inGame: Bool = false
    
    var p1: Paddle = Paddle()
    var p2: Paddle = Paddle()
    
    var p1Goal: SKSpriteNode = SKSpriteNode()
    var p2Goal: SKSpriteNode = SKSpriteNode()
    
    var p1Controller: Controller = Controller(player: Paddle())
    var p2Controller: Controller = Controller(player: Paddle())
    
    var p1ScoreLabel: SKLabelNode = SKLabelNode()
    var p2ScoreLabel: SKLabelNode = SKLabelNode()
    
    var p1Score: Int = 0
    var p2Score: Int = 0
    
    var ball = Ball()
    
    var touching = false
    var touch: UITouch = UITouch()
    
    var timeSinceSwitchedSides: Double = 0
    var onP1Side: Bool = true
    
    public override func sceneDidLoad() {
        self.physicsWorld.contactDelegate = self
        self.camera = childNode(withName: "Camera") as? SKCameraNode
        p1 = childNode(withName: "P1Paddle") as! Paddle
        p2 = childNode(withName: "P2Paddle") as! Paddle
        p1Goal = childNode(withName: "P1Goal") as! SKSpriteNode
        p2Goal = childNode(withName: "P2Goal") as! SKSpriteNode
        p1ScoreLabel = childNode(withName: "P1Score") as! SKLabelNode
        p2ScoreLabel = childNode(withName: "P2Score") as! SKLabelNode
        //p1Controller = BasicAIController(player: p1, reactionTime: (1.0/60.0))
        p1Controller = PlayerController(player: p1)
        if (GameData.instance.isBot) {
            p2Controller = BasicAIController(player: p2, reactionTime: GameData.instance.reactionTime)
        } else {
            p2Controller = MLAIController(player: p2, model: GameData.instance.aiModel)
        }
        
        scoreToWin = GameData.instance.winScore

        super.sceneDidLoad()
        beginGame()
        
        GameData.instance.mlData = GameMLManager()
        //spawnBall()
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            touch = t
            touching = true
        }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        touching = false
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        //touching = false
    }
    
    //TODO remove
    //private var mlTest: Bool = true
    
    public override func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
        
        var delta: CFTimeInterval = currentTime // no reason to make it optional
        if let luti = lastUpdateTimeInterval {
            delta = currentTime - luti
        }
        
        lastUpdateTimeInterval = currentTime
        
        /*(let mlController: MLAIController = MLAIController(player: p2)
        //ML Test remove
        if (GameData.instance.mlData.index >= 1 && mlTest) {
            
            //print(GameData.instance.mlData.minibatches[0].labelsMove.stringRepresentation())
            //inGame = false
            for _ in 1...1000 { //number of  iterations
                for i in 0...0 {
                    let minibatch: DataMinibatch = GameData.instance.mlData.minibatches[i]
                    mlController.train(dataMinibatch: minibatch)
                }
            }
            print("AI trained")
            //print(mlController.moveModel.predict(data: GameData.instance.mlData.minibatches[0].data).stringRepresentation())
            p2Controller = mlController
            mlTest = false
            let modelStr: String = mlController.moveModel.stringRepresentation()
            print(modelStr)
            //exit(EXIT_SUCCESS)
        }*/
        
        if (inGame) {
            ball.spin()
            ball.clampVelocity()
            
            //Check if the ball is on p1's side
            let currentlyOnP1Side = ball.position.y < 0
            if currentlyOnP1Side == onP1Side {
                timeSinceSwitchedSides += delta
            } else {
                timeSinceSwitchedSides = 0
                onP1Side = currentlyOnP1Side
            }
            
            //Get sensors
            let p1Sensor: Sensor = Sensor(ball: ball, selfPaddle: p1, opponentPaddle: p2, touchPos: touch.location(in: self), touching: touching, flippedY: false, timeSinceSwitchedSides: timeSinceSwitchedSides)
            let p2Sensor: Sensor = p1Sensor.getOpponentSensor()
            

            
            
            //Logs ML if p1 is player and logging is on
            if /*p1Controller as? PlayerController != nil &&*/ GameData.instance.logML {
                let p1MoveData = p1Controller.getMoveData(sensor: p1Sensor)
                GameData.instance.mlData.enterData(sensor: p1Sensor, moveData: p1MoveData)
            }
            
            //Moves paddles
            p1Controller.control(sensor: p1Sensor)
            p2Controller.control(sensor: p2Sensor)
            
        }
        

    }
    
    public func didBegin(_ contact: SKPhysicsContact) {
        if (contact.bodyA == ball.phys || contact.bodyB == ball.phys) {
            var hitGoal: Bool = false
            var p1Won: Bool = true
            if(contact.bodyA == p1Goal.physicsBody || contact.bodyB == p1Goal.physicsBody) {
                p2Score += 1
                hitGoal = true
                p1Won = false
            }
            if(contact.bodyA == p2Goal.physicsBody || contact.bodyB == p2Goal.physicsBody) {
                p1Score += 1
                hitGoal = true
                p1Won = true
            }
            
            if hitGoal {
                updateScoreText()
                explosionEffect(position: ball.position)
                ball.removeFromParent()
                endRound(p1Won: p1Won)
            }
            
            
        } else {
            print("Check collisions")
        }
    }
    
    private func updateScoreText(){
        p1ScoreLabel.text = p1Score.description
        p2ScoreLabel.text = p2Score.description
    }
    
}

//Rounds
public extension GameScene {
    
    public func beginGame() {
        let winScoreText: String = "First to " + scoreToWin.description
        let effectTxt1: SKLabelNode = SKLabelNode()
        effectTxt1.text = winScoreText
        effectTxt1.position = CGPoint(x: -600, y: 10)
        effectTxt1.fontName = "Helvetica Neue Light"
        effectTxt1.fontSize = CGFloat(24)
        let goText: String = "Go!"
        let effectTxt2: SKLabelNode = SKLabelNode()
        effectTxt2.text = goText
        effectTxt2.position = CGPoint(x: -600, y: 10)
        effectTxt2.fontName = "Helvetica Neue Light"
        effectTxt2.fontSize = CGFloat(24)
        //Moves to centre, pauses, then moves offscreen and pauses again
        let centre: SKAction = SKAction.move(to: CGPoint(x: 0, y: 10), duration: 1.0)
        let pause: SKAction = SKAction.wait(forDuration: 1.0)
        let offScreen: SKAction = SKAction.move(to: CGPoint(x: 600, y: 10), duration: 1.0)
        let fullEffect: SKAction = SKAction.sequence([centre, pause, offScreen])
        //Shows the effect
        addChild(effectTxt1)
        addChild(effectTxt2)
        effectTxt1.run(fullEffect, completion: {
            effectTxt2.run(fullEffect, completion: {
                self.beginRound()
                effectTxt2.removeFromParent()
            })
            effectTxt1.removeFromParent()
        })
    }
    
    public func beginRound() {
        let effect: SKSpriteNode = SKSpriteNode(imageNamed: "ring.png")
        addChild(effect)
        let shrink: SKAction = SKAction.scale(to: CGFloat(0), duration: 1.0)
        effect.run(shrink, completion: {//() -> Void in
            self.spawnBall()
            effect.removeFromParent()
        })
    }
    
    public func spawnBall(){
        ball = Ball(imageNamed: "ball.png")
        addChild(ball)
        ball.launch()
        inGame = true;
        explosionEffect(position: CGPoint.zero)
    }
    
    public func endRound(p1Won p1DidWin: Bool) {
        inGame = false
        timeSinceSwitchedSides = 0
        let p1WonText: String = "Player 1 Scores!"
        let p2WonText: String = "Player 2 Scores!"
        let effect: SKLabelNode = SKLabelNode()
        effect.position = CGPoint(x: -600, y: 10)
        effect.fontName = "Helvetica Neue Light"
        effect.fontSize = CGFloat(24)
        if p1DidWin {
            effect.text = p1WonText
        } else {
            effect.text = p2WonText
        }
        //Moves to centre, pauses, then moves offscreen and pauses again
        let centre: SKAction = SKAction.move(to: CGPoint(x: 0, y: 10), duration: 1.0)
        let pause: SKAction = SKAction.wait(forDuration: 1.0)
        let offScreen: SKAction = SKAction.move(to: CGPoint(x: 600, y: 10), duration: 1.0)
        let fullEffect: SKAction = SKAction.sequence([centre, pause, offScreen, pause])
        //Show the effect
        addChild(effect)
        effect.run(fullEffect, completion: {
            self.beginRound()
            
            if (self.p1Score >= self.scoreToWin) {
                self.endGame(p1Won: true)
            } else if (self.p2Score >= self.scoreToWin) {
                self.endGame(p1Won: false)
            }
            
            effect.removeFromParent()
        })
    }
    
    public func endGame(p1Won: Bool) {
        GameData.instance.won = p1Won
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = GameOverScene(fileNamed: "GameOverScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
}

//Effects
public extension GameScene {
    
    public func explosionEffect(position p: CGPoint) {
        let particleEmissionTime: TimeInterval = 2.0
        let delay: SKAction = SKAction.wait(forDuration: particleEmissionTime)
        let remove: SKAction = SKAction.removeFromParent()
        let particleEffect: SKEmitterNode = SKEmitterNode(fileNamed: "Explosion.sks")!
        particleEffect.position = p
        addChild(particleEffect)
        particleEffect.run(SKAction.sequence([delay, remove]))
    }
    
}
