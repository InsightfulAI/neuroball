import Foundation
import SpriteKit

public class HelpScene: SKScene {
    
    private var buttons: [Button] = []
    
    public override func sceneDidLoad() {
        let text: SKLabelNode = childNode(withName: "text") as! SKLabelNode
        text.preferredMaxLayoutWidth = CGFloat(400)
        
        let button: Button = childNode(withName: "button") as! Button
        button.addAction(action: go)
        buttons.append(button)
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t: UITouch in touches {
            for button: Button in buttons {
                _ = button.checkClick(pointer: t.location(in: self))
            }
        }
    }
    
    private func go() {
        GameData.instance.isBot = true
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = GameScene(fileNamed: "GameScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
}
