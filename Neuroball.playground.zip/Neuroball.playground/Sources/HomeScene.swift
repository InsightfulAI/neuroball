import Foundation
import SpriteKit

public class HomeScene: SKScene {
    
    private var buttons: [Button] = []
    
    public override func sceneDidLoad() {
        let playBotButton = childNode(withName: "playBot") as! Button
        playBotButton.addAction(action: playBot)
        buttons.append(playBotButton)
        let playNNButton = childNode(withName: "playNN") as! Button
        playNNButton.addAction(action: playNN)
        
        if (!GameData.instance.tutorial) {
            buttons.append(playNNButton)
        } else {
            playNNButton.removeFromParent()
        }
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t: UITouch in touches {
            for button: Button in buttons {
                _ = button.checkClick(pointer: t.location(in: self))
            }
        }
    }
    
    private func playBot() {
        GameData.instance.isBot = true
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = HelpScene(fileNamed: "HelpScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
    
    private func playNN() {
        GameData.instance.isBot = false
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = AISelectScene(fileNamed: "AISelectScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
    
}
