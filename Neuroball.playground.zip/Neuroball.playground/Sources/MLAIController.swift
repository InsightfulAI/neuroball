import Foundation
import CoreGraphics

public class MLAIController: Controller {
    
    private let learningRate: Double = 0.000001
    private let stopMovingRadius: CGFloat = CGFloat(6.0)
    
    public var moveModel: NNModel = NNModel.init(layerSizes: [DataMinibatch.numEntries, 20, 20, DataMinibatch.numLabelsMove], type: NNModel.NNType.regressor)
    
    public override init(player paddle: Paddle) {
        super.init(player: paddle)
    }
    
    public init(player paddle: Paddle, model: String) {
        super.init(player: paddle)
        moveModel = NNModel.loadModel(savedModel: model)
    }
    
    public func train(dataMinibatch mb: DataMinibatch) {
        //moveModel.gradientCheck(X: mb.data, Y: mb.labelsMove)
        let moveCost = moveModel.trainGradientDescent(data: mb.data, labels: mb.labelsMove, learningRate: learningRate)
        //print("Move model cost: " + moveCost.description)
    }
    
    public override func getMoveData(sensor gameSensor: Sensor) -> MoveData {
        let moveMat: Matrix = moveModel.predict(data: gameSensor.getLabelsVector())
        let desiredMoveLocation: CGVector = CGVector(dx: moveMat[0, 0], dy: moveMat[1, 0])
        var shouldMove = true
        let direction: CGVector = desiredMoveLocation - CGVector(dx: gameSensor.selfX, dy: gameSensor.selfY)
        if direction.getMagnitude() < stopMovingRadius {
            shouldMove = false
        }
        return MoveData(direction: direction, shouldMove: shouldMove, desiredMoveLocation: desiredMoveLocation)
    }
}
