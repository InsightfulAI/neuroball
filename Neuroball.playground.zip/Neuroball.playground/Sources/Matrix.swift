import Foundation

import Accelerate

//https://developer.apple.com/documentation/accelerate/blas
//https://medium.com/@JLHLonline/machine-learning-in-swift-the-matrix-5ff1c8fd5e96
//https://stackoverflow.com/a/49735414

public class Matrix{
    
    public let m: Int
    public let n: Int
    
    var data: [Double]
    
    private init(rows m: Int, columns n: Int, dataArray data: [Double]) {
        self.m = m
        self.n = n
        self.data = data
    }
    
    func validIndex(rows m: Int, columns n: Int) -> Bool {
        return m >= 0 && m < self.m && n >= 0 && n < self.n
    }
    
    subscript(m: Int, n: Int) -> Double {
        get {
            assert(validIndex(rows: m, columns: n), "Index out of range!")
            return data[(m * self.n) + n]
        }
        set {
            assert(validIndex(rows: m, columns: n), "Index out of range!")
            data[(m * self.n) + n] = newValue
        }
    }
    
    func trn() -> Matrix {
        return Matrix.transpose(matrix: self)
    }
    
    func duplicate() -> Matrix {
        return Matrix(rows: m, columns: n, dataArray: data)
    }
    
}

//Debug
public extension Matrix{
    private func assert(_ condition: Bool, _ message: String) {
        Matrix.assert(condition, message)
    }
    
    private class func assert(_ condition: Bool, _ message: String) {
        if !condition {
            print(message)
            Thread.callStackSymbols.forEach{print($0)}
            exit(EXIT_FAILURE)
        }
    }
}

//Matrix construction
public extension Matrix {
    public class func zeroes(rows m: Int, columns n: Int) -> Matrix {
        let data = Array(repeating: 0.0, count: m*n)
        return Matrix(rows: m, columns: n, dataArray: data)
    }
    
    public class func ones(rows m: Int, columns n: Int) -> Matrix {
        let data = Array(repeating: 1.0, count: m*n)
        return Matrix(rows: m, columns: n, dataArray: data)
    }
    
    public class func identity(size s: Int) -> Matrix {
        let matrix: Matrix = zeroes(rows: s, columns: s)
        for i in 0...(s-1) {
            matrix[i, i] = 1
        }
        return matrix
    }
    
    //Returns a matrix filled with uniformly distributed random numbers from 0.0 (inclusive) to 1.0 (inclusive)
    public class func rand(rows m: Int, columns n: Int) -> Matrix {
        let matrix = zeroes(rows: m, columns: n)
        for i in 0...(m*n-1) {
            matrix.data[i] = Double.random(in: 0.0...1.0)
        }
        return matrix
    }
    
}

//Matrix arithmetic operations
infix operator •
public extension Matrix {
    
    public class func sameSize(leftM lm: Int, leftN ln: Int, rightM rm: Int, rightN rn: Int) -> Bool {
        return (lm == rm) && (ln == rn)
    }
    
    public class func multiplicationPossible(leftN ln: Int, rightM rm: Int) -> Bool {
        return ln == rm
    }
    
    //Matrix addition (vectorised)
    public final class func + (left: Matrix, right: Matrix) -> Matrix {
        assert(sameSize(leftM: left.m, leftN: left.n, rightM: right.m, rightN: right.n), "Size mismatch during matrix addition!")
        var newData: [Double] = right.data
        cblas_daxpy(Int32(left.m*left.n), 1.0, left.data, Int32(1), &newData, Int32(1))
        return Matrix(rows: left.m, columns: left.n, dataArray: newData)
    }
    
    //Matrix-scalar addition with broadcasting (vectorised)
    public final class func + (left: Double, right: Matrix) -> Matrix {
        let addMatrix = left*ones(rows: right.m, columns: right.n)
        return addMatrix + right
    }
    
    public final class func + (left: Matrix, right: Double) -> Matrix {
        return right + left
    }
    
    //Negates a matrix (vectorised
    
    public final class prefix func - (matrix: Matrix) -> Matrix {
        return -1*matrix
    }
    
    //Matrix subtraction (vectorised)
    public final class func - (left: Matrix, right: Matrix) -> Matrix {
        return left + (-right)
    }
    
    //Matrix-scalar subtraction with broadcastin (vectorised)
    public final class func - (left: Matrix, right: Double) -> Matrix {
        return left + (-right)
    }
    
    public final class func - (left: Double, right: Matrix) -> Matrix {
        return left + (-right)
    }
    
    //Matrix-scalar multiplication (vectorised)
    public final class func * (left: Double, right: Matrix) -> Matrix {
        let newMatrix: Matrix = zeroes(rows: right.m, columns: right.n)
        cblas_daxpy(Int32(right.m*right.n), left, right.data, Int32(1), &newMatrix.data, Int32(1))
        return newMatrix
    }
    
    public final class func * (left: Matrix, right: Double) -> Matrix {
        return right*left
    }
    
    //Matrix elementwise multiplication (not vectorised)
    public final class func * (left: Matrix, right: Matrix) -> Matrix {
        assert(sameSize(leftM: left.m, leftN: left.n, rightM: right.m, rightN: right.n), "Size mismatch during matrix elementwise multiplication!")
        let m = left.m, n = left.n
        let newMatrix: Matrix = zeroes(rows: m, columns: n)
        for i in 0...(m-1) {
            for j in 0...(n-1) {
                newMatrix[i, j] = left[i, j] * right[i, j]
            }
        }
        return newMatrix
    }
    
    //Matrix elementwise division (not vectorised)
    public final class func / (left: Matrix, right: Matrix) -> Matrix {
        assert(sameSize(leftM: left.m, leftN: left.n, rightM: right.m, rightN: right.n), "Size mismatch during matrix elementwise division!")
        let m = left.m, n = left.n
        let newMatrix: Matrix = zeroes(rows: m, columns: n)
        for i in 0...(m-1) {
            for j in 0...(n-1) {
                newMatrix[i, j] = left[i, j]/right[i, j]
            }
        }
        return newMatrix
    }
    
    //Matrix multiplication (bullet is option 8) (vectorised)
    public final class func • (left: Matrix, right: Matrix) -> Matrix {
        return dot(left: left, leftTransposed: false, right: right, rightTransposed: false)
    }
    
    //Matrix multiplication with optional transpose (vectorised)
    public final class func dot(left a: Matrix, leftTransposed aT: Bool, right b: Matrix, rightTransposed bT: Bool) -> Matrix {
        let order: CBLAS_ORDER = CblasRowMajor
        var leftM: Int = a.m
        var leftN: Int = a.n
        var rightM: Int = b.m
        var rightN: Int = b.n
        var leftTranspose: CBLAS_TRANSPOSE = CblasNoTrans
        var rightTranspose: CBLAS_TRANSPOSE = CblasNoTrans
        if aT {
            leftM = a.n
            leftN = a.m
            leftTranspose = CblasTrans
        }
        if bT {
            rightM = b.n
            rightN = b.m
            rightTranspose = CblasTrans
        }
        assert(multiplicationPossible(leftN: leftN, rightM: rightM), "Size mismatch during matrix multiplication!")
        let newMatrix: Matrix = zeroes(rows: leftM, columns: rightN)
        cblas_dgemm(order, leftTranspose, rightTranspose, Int32(leftM), Int32(rightN), Int32(leftN), 1.0, a.data, Int32(a.n), b.data, Int32(b.n), 1.0, &newMatrix.data, Int32(newMatrix.n))
        return newMatrix
    }
    
    //Returns the sum of all elements in a matrix (vectorised)
    public final class func sum(matrix mat: Matrix) -> Double {
        var result: Double = 0.0
        vDSP_sveD(mat.data, 1, &result, vDSP_Length(mat.m*mat.n))
        return result
    }
    
    public final class func sumSq(matrix mat: Matrix) -> Double {
        let sqMat: Matrix = mat.performOperation(function: sq)
        return sum(matrix: sqMat)
    }
    
    private final class func sq(x: Double) -> Double {
        return x*x
    }
    
    
    //Sums up all the rows in the matrix (not vectorised)
    public final class func sumRows(matrix mat: Matrix) -> Matrix {
        let result: Matrix = zeroes(rows: mat.m, columns: 1)
        for i in 0...(mat.m-1) {
            var sum: Double = 0
            for j in 0...(mat.n-1) {
                sum += mat[i, j]
            }
            result[i, 0] = sum
        }
        return result
    }
    
    //Sums up all the columns in the matrix (not vectorised)
    public final class func sumColumns(matrix mat: Matrix) -> Matrix {
        let result: Matrix = zeroes(rows: 1, columns: mat.n)
        for j in 0...(mat.n-1) {
            var sum: Double = 0
            for i in 0...(mat.m-1) {
                sum += mat[i, j]
            }
            result[0, j] = sum
        }
        return result
    }
    
    //Calculates the Frobenius norm of a matrix (vectorised)
    public final class func frobeniusNorm(matrix mat: Matrix) -> Double {
        return cblas_dnrm2(Int32(mat.m*mat.n), mat.data, 1)
    }
    
    //Performs an arbitrary function on each element of the matrix (not vectorised)
    public final func performOperation(function f: (Double) -> Double) -> Matrix {
        let result: Matrix = Matrix.zeroes(rows: m, columns: n)
        for i in 0...(m*n-1) {
            result.data[i] = f(data[i])
        }
        return result
    }
    
}

//Other matrix functions
public extension Matrix {
    
    public final func setRow(value v: Matrix, row m: Int) {
        assert(!(m < 0 || m >= self.m), "Row out of bounds")
        assert(v.n == self.n && v.m == 1, "Row size mismatch")
        for i in 0...(n-1) {
            self[m, i] = v[0, i]
        }
    }
    
    public final func setColumn(value v: Matrix, column n: Int) {
        assert(!(n < 0 || n >= self.n), "Column out of bounds")
        assert(v.m == self.m && v.n == 1, "Column size mismatch")
        for i in 0...(m-1) {
            self[i, n] = v[i, 0]
        }
    }
    
    //Returns the transpose of a matrix (not vectorised, use dot for multiplication with transpose)
    public final class func transpose(matrix a: Matrix) -> Matrix {
        let b: Matrix = zeroes(rows: a.n, columns: a.m)
        for i in 0...(a.m-1) {
            for j in 0...(a.n-1) {
                b[j, i] = a[i, j]
            }
        }
        return b
    }
    
    //Reshapes matrix (duplicates the matrix in the process)
    public final class func reshape(matrix a: Matrix, rows m: Int, columns n: Int) -> Matrix{
        let dataCopy: [Double] = a.data
        return Matrix(rows: m, columns: n, dataArray: dataCopy)
    }
    
    //Repeats a matrix vertically [1, 2, 3] becomes 3x3 matrix (not vectorised)
    public final class func repeatVertical(matrix a: Matrix, times t: Int) -> Matrix {
        let newData: [Double] = Array(repeating: a.data, count: t).flatMap{$0}
        return Matrix(rows: a.m*t, columns: a.n, dataArray: newData)
    }
    
    //Repeats a matrix horizontally [1, 2, 3] becomes 9x1 matrix (not vectorised)
    public final class func repeatHorizontal(matrix a: Matrix, times t: Int) -> Matrix {
        let trn: Matrix = transpose(matrix: a)
        return repeatVertical(matrix: trn, times: t).trn()
    }
    
    //Appends two matrices (not vectorised)
    public final class func appendVertical(above a: Matrix, below b: Matrix) -> Matrix{
        assert(a.n == b.n, "Size mismatch during vertical appending")
        let m: Int = a.m + b.m
        let n: Int = a.n
        let result: Matrix = zeroes(rows: m, columns: n)
        for j in 0...(n-1) {
            for i in 0...(a.m-1) {
                result[i, j] = a[i, j]
            }
            for i in a.m...(m-1) {
                result[i, j] = b[i - a.m, j]
            }
        }
        return result
    }
    
    //Appends two matrices (not vectorised) (probably slow)
    public final class func appendHorizontal(left l: Matrix, right r: Matrix) -> Matrix{
        //Irresponsible call of other functions, slow but works
        return appendVertical(above: l.trn(), below: r.trn()).trn()
    }
    
    public final class func truncate(matrix mat: Matrix, endRow m: Int, endColumn n: Int) -> Matrix {
        return truncate(matrix: mat, startRow: 0, startColumn: 0, endRow: m, endColumn: n)
    }
    
    public final class func truncate(matrix mat: Matrix, startRow m1: Int, startColumn n1: Int, endRow m2: Int, endColumn n2: Int) -> Matrix {
        assert(mat.validIndex(rows: m1, columns: n1) && mat.validIndex(rows: m2, columns: n2) && m2>=m1 && n2>=n1, "Truncating out of bounds")
        let m: Int = m2-m1+1
        let n: Int = n2-n1+1
        let result: Matrix = Matrix.zeroes(rows: m, columns: n)
        for i in 0...(m-1) {
            for j in 0...(n-1) {
                result[i, j] = mat[i + m1, j + n1]
            }
        }
        return result
    }
    
}

//Storing and loading a matrix as a string
public extension Matrix {
    
    public class C {
        static let mChar: String = "m"
        static let nChar: String = "n"
        static let endMNChar: String = ";"
        static let beginBodyChar: String = "["
        static let nextNumChar: String = "|"
        static let endBodyChar: String = "]"
        static let format: String = "%.15g"
        
        public enum LoadState{
            case standby, loadM, loadN, loadBody, finished
        }
        
    }
    
    public func stringRepresentation() -> String {
        var result: String = ""
        
        //Stores the size of the matrix
        result += C.mChar
        result += String(m)
        result += C.endMNChar
        result += " " //Space for human readability
        result += C.nChar
        result += String(n)
        result += C.endMNChar
        result += " " //Space for human readability
        
        //Stores the body of the matrix
        result += C.beginBodyChar
        for number: Double in data {
            result += String(format: C.format, number)
            result += C.nextNumChar
            result += " " //Space for human readability
        }
        result += C.endBodyChar
        return result
    }
    
    public final class func loadFromString(in string: String) -> Matrix {
        var m: Int = 0
        var n: Int = 0
        var state: C.LoadState = C.LoadState.standby
        var num: String = ""
        var i: Int = 0
        var data: [Double] = []
        var matrix: Matrix = zeroes(rows: 1, columns: 1)
        for char: Character in string {
            let charStr = String(char)
            if charStr == " " {
                continue //skip if blank
            }
            if charStr == C.mChar {
                state = C.LoadState.loadM
                continue
            }
            if charStr == C.nChar {
                state = C.LoadState.loadN
                continue
            }
            if charStr == C.beginBodyChar {
                state = C.LoadState.loadBody
                data = Array(repeating: 0.0, count: m*n)
                continue
            }
            switch state {
            case C.LoadState.loadM:
                if charStr == C.endMNChar {
                    m = Int(num)!
                    state = C.LoadState.standby
                    num = ""
                } else {
                    num += charStr
                }
            case C.LoadState.loadN:
                if charStr == C.endMNChar {
                    n = Int(num)!
                    state = C.LoadState.standby
                    num = ""
                } else {
                    num += charStr
                }
            case C.LoadState.loadBody:
                if charStr == C.endBodyChar {
                    state = C.LoadState.finished
                    matrix =  Matrix(rows: m, columns: n, dataArray: data)
                } else if charStr == C.nextNumChar {
                    data[i] = Double(num)!
                    num = ""
                    i += 1
                } else {
                    num += charStr
                }
            default:
                if state == C.LoadState.finished {
                    break
                }
            }
        }
        return matrix
    }
    
}
