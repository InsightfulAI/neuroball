import Foundation

public extension Matrix {
    class func test() {
        let matA: Matrix = Matrix.ones(rows: 2, columns: 3)
        print(matA.stringRepresentation())
        let matB: Matrix = Matrix.zeroes(rows: 1, columns: 3)
        print(matB.stringRepresentation())
        let matC: Matrix = Matrix.appendVertical(above: matA, below: matB)
        print(matC.stringRepresentation())
        //let matD: Matrix = (2*matC)•(matA.trn())
        //print(matD.stringRepresentation())
        let matD: Matrix = Matrix.dot(left: 2*matC, leftTransposed: false, right: matA, rightTransposed: true)
        print(matD.stringRepresentation())
        let matE: Matrix = Matrix.reshape(matrix: matD, rows: 1, columns: matD.m*matD.n)
        print(matE.stringRepresentation())
        print(Matrix.reshape(matrix: matE, rows: 2, columns: 3).stringRepresentation())
        print(Matrix.loadFromString(in: matA.stringRepresentation()).stringRepresentation())
        let matF: Matrix = Matrix.rand(rows: 3, columns: 1)
        print(matF.stringRepresentation())
        print(Matrix.appendHorizontal(left: matF, right: matC).stringRepresentation())
        let matG: Matrix = matC.duplicate()
        matG.setColumn(value: matF, column: 1)
        print(matG.stringRepresentation())
        matG.setRow(value: matB, row: 2)
        print(matG.stringRepresentation())
        let matH: Matrix = Matrix.rand(rows: 4, columns: 4)
        print(matH.stringRepresentation())
        print(Matrix.truncate(matrix: matH, endRow: 1, endColumn: 1).stringRepresentation())
        print(Matrix.truncate(matrix: matH, startRow: 1, startColumn: 1, endRow: 2, endColumn: 2).stringRepresentation())
        print(Matrix.truncate(matrix: matH, startRow: 1, startColumn: 1, endRow: 1, endColumn: 1).stringRepresentation())
        print(matD.stringRepresentation())
        let matI: Matrix = Matrix.rand(rows: 3, columns: 2)
        print(matI.stringRepresentation())
        print((matD*matI).stringRepresentation())
        let matJ: Matrix = Matrix.rand(rows: 1, columns: 5).performOperation(function: NNModel.logistic)
        print(matJ.stringRepresentation())
    }
    
    class func multTest() {
        let matA: Matrix = Matrix.ones(rows: 3, columns: 1)
        let matB: Matrix = Matrix.ones(rows: 1, columns: 3)
        print(matA.stringRepresentation())
        print(matB.stringRepresentation())
        let matC: Matrix = matA•matB
        print(matC.stringRepresentation())
        let matD: Matrix = matB•matA
        print(matD.stringRepresentation())
        let matE: Matrix = Matrix.dot(left: matA, leftTransposed: true, right: matA, rightTransposed: false)
        print(matE.stringRepresentation())
    }
    
    
    
}
