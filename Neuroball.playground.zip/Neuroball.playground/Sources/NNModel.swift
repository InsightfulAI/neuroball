import Foundation

//A multi-layer perceptron model API
public class NNModel {
    
    public static let activation: (Double) -> Double = relu
    public static let activationDerivative: (Double) -> Double = NNModel.reluDerivative
    var W: [Matrix] = []
    var b: [Matrix] = []
    
    var layerSizes: [Int]
    
    var type: NNType
    
    public init(W: [Matrix], b: [Matrix], type: NNType) {
        self.W = W
        self.b = b
        self.type = type
        layerSizes = []
        layerSizes.append(W[0].n)
        for i in 0...(W.count - 1) {
            layerSizes.append(b[i].m)
        }
    }
    
    public init(layerSizes: [Int], type: NNType) {
        self.layerSizes = layerSizes
        self.type = type
        for i in 0...(layerSizes.count-2) {
            W.append(Matrix.rand(rows: layerSizes[i+1], columns: layerSizes[i]) * sqrt(2.0/Double(layerSizes[i])))
            b.append(Matrix.zeroes(rows: layerSizes[i+1], columns: 1))
        }
    }
    
    //Single linear forward
    private static func linearForward(A: Matrix, W: Matrix, b: Matrix) -> Matrix {
        let Z: Matrix = (W•A) + Matrix.repeatHorizontal(matrix: b, times: A.n)
        return Z
    }
    
    //Forward propagates
    private func forwardProp(data X: Matrix) -> [Matrix] {
        var A: [Matrix] = []
        A.append(X)
        for i in 0...(layerSizes.count-3) {
            let Z: Matrix = NNModel.linearForward(A: A[i], W: self.W[i], b: self.b[i])
            A.append(Z.performOperation(function: NNModel.activation))

        }
        
        //Final layer depends on neural network type
        let i = layerSizes.count-2
        let ZL: Matrix = NNModel.linearForward(A: A[i], W: self.W[i], b: self.b[i])

        switch type {
        case .regressor:
            //Linear final layer output
            A.append(ZL)
        case .classifier:
            //Logistic final layer output
            A.append(ZL.performOperation(function: NNModel.logistic))
        }
        
        return A
        
    }
    
    //Computes the cost
    public func computeCost(predictions AL: Matrix, labels Y: Matrix) -> Double {
        let m = Y.n
        var cost: Double = 0.0
        switch type {
        case .regressor:
            cost = (0.5/Double(m)) * Matrix.sumSq(matrix: (AL - Y))
            //print(AL.stringRepresentation())
            //print(Y.stringRepresentation())
        case .classifier:
            cost = (-1.0/Double(m)) * Matrix.sum(matrix: Y*(AL.performOperation(function: log)) + (1-Y)*((1-AL).performOperation(function: log)))
        }
        return cost
    }
    
    private func linearBackward(dZ: Matrix, APrev: Matrix, W: Matrix) -> SingleDerivatives {
        let m = APrev.n
        let dW = (1.0/Double(m)) * Matrix.dot(left: dZ, leftTransposed: false, right: APrev, rightTransposed: true)
        let db = (1.0/Double(m)) * Matrix.sumRows(matrix: dZ)
        let dAPrev = Matrix.dot(left: W, leftTransposed: true, right: dZ, rightTransposed: false)
        return SingleDerivatives(dW: dW, db: db, dAPrev: dAPrev)
    }
    
    private func backProp(labels Y: Matrix, A: [Matrix]) -> Gradients{
        
        let L = layerSizes.count
        
        //var dZ: [Matrix] = []
        var dA: [Matrix] = []
        var dW: [Matrix] = []
        var db: [Matrix] = []
        var dZ: [Matrix] = []
        
        //Initialise backpropagation
        var dZL: Matrix
        switch type {
        case .regressor:
            dA.append(A[L-1] - Y) //TODO still issue here, appears to be multiplied by a scalar
            //dA[0] = dA[0] * getScalarHack(AL: A[L-1], Y: Y, dAL: dA[0]) //Some crazy hack that fixes the above issue
            //dA[0] = estimate_dAL(AL: A[L-1], Y: Y) //Backup plan
            dZL = dA[0]
        case .classifier:
            dA.append(-(Y/A[L-1]) - ((1-Y)/(1-A[L-1])))
            //dZL = dA[0].performOperation(function: NNModel.logisticDerivative2)
            dZL = A[L-1] - Y
        }
        
        //dZL = A[L-1] - Y
        
        let derivativesL: SingleDerivatives = linearBackward(dZ: dZL, APrev: A[L-2], W: W[L-2])
        dA.append(derivativesL.dAPrev)
        dW.append(derivativesL.dW)
        db.append(derivativesL.db)
        dZ.append(dZL)
        
        
        for i in (0...(L-3)).reversed() {
            let dZCurrent: Matrix = Matrix.dot(left: W[i+1], leftTransposed: true, right: dZ[L-i-3], rightTransposed: false) * A[L-i-2].performOperation(function: NNModel.activationDerivative)
            let derivatives: SingleDerivatives = linearBackward(dZ: dZCurrent, APrev: A[i], W: W[i])
            dA.append(derivatives.dAPrev)
            dW.append(derivatives.dW)
            db.append(derivatives.db)
            dZ.append(dZCurrent)
        }
        
        dA = dA.reversed()
        dW = dW.reversed()
        db = db.reversed()
        
        return Gradients(dW: dW, db: db, dA: dA)
    }
    
    private func gradientDescent(gradients: Gradients, learningRate alpha: Double) {
        //print(alpha)
        for i in 0...(layerSizes.count-2) {
            //print(W[i].stringRepresentation())
            W[i] = W[i] - (alpha*gradients.dW[i])
            //print(W[i].stringRepresentation())
            b[i] = b[i] - (alpha*gradients.db[i])
        }
    }
    
    //Trains one iteration of gradient descent, returns cost
    public func trainGradientDescent(data X: Matrix, labels Y: Matrix, learningRate alpha: Double) -> Double{
        let A: [Matrix] = forwardProp(data: X)
        let cost: Double = computeCost(predictions: A[A.count-1], labels: Y)
        let gradients: Gradients = backProp(labels: Y, A: A)
        gradientDescent(gradients: gradients, learningRate: alpha)
        //print(gradients.dW[2].stringRepresentation())
        return cost
    }
    
    //Returns predictions
    public func predict(data X: Matrix) -> Matrix {
        let A: [Matrix] = forwardProp(data: X)
        return A[A.count-1]
    }
    
    public enum NNType {
        case regressor, classifier
    }
    
    private struct SingleDerivatives {
        let dW: Matrix
        let db: Matrix
        let dAPrev: Matrix
    }
    
    private struct Gradients {
        let dW: [Matrix]
        let db: [Matrix]
        let dA: [Matrix]
    }
    
}

//For saving and loading
public extension NNModel {
    
    //https://stackoverflow.com/a/34940183
    
    class SaveLoad {
        static let commandStr: String = "$"
        static let regressorStr = "R"
        static let classifierStr = "C"
        static let weightsStr: String = "W"
        static let biasStr: String = "B"
        static let beginMatrix: String = "{"
        static let endMatrix: String = "}"
        
        enum State {
            case standby, parseCommand, loadW, loadB
        }
    }
    
    //Turns the entire neural network into a string
    public func stringRepresentation() -> String {
        var representation: String = ""
        
        //NN type
        representation += SaveLoad.commandStr
        switch type {
        case .classifier:
            representation += SaveLoad.classifierStr
        case .regressor:
            representation += SaveLoad.regressorStr
        }
        
        //Add new line for human readability
        representation += "\n"
        
        //Weights
        representation += SaveLoad.commandStr
        representation += SaveLoad.weightsStr
        
        for weightsLayer: Matrix in W {
            //Add new line for human readability
            representation += "\n"
            
            //Print the matrix
            representation += SaveLoad.beginMatrix
            representation += weightsLayer.stringRepresentation()
            representation += SaveLoad.endMatrix
        }
        
        //Add new line for human readability
        representation += "\n"
        
        //Bias
        representation += SaveLoad.commandStr
        representation += SaveLoad.biasStr
        
        for biasLayer: Matrix in b {
            //Add new line for human readability
            representation += "\n"
            
            //Print the matrix
            representation += SaveLoad.beginMatrix
            representation += biasLayer.stringRepresentation()
            representation += SaveLoad.endMatrix
        }
        
        return representation
    }
    
    public final class func loadModel(savedModel: String) -> NNModel{
        var W: [Matrix] = []
        var b: [Matrix] = []
        var type: NNType = NNType.regressor
        
        var loadState: SaveLoad.State = SaveLoad.State.standby
        var loadStr: String = ""
        var loadMat: Bool = false
        for char: Character in savedModel {
            let charStr = String(char)
            if charStr == SaveLoad.commandStr {
                loadState = SaveLoad.State.parseCommand
                continue
            }
            switch loadState {
            case .parseCommand:
                //Parse the type of neural network
                if charStr == SaveLoad.classifierStr {
                    type = NNType.classifier
                    loadState = .standby
                    continue
                } else if charStr == SaveLoad.regressorStr {
                    type = NNType.regressor
                    loadState = .standby
                    continue
                }
                //Switches state to loading the matrices
                if charStr == SaveLoad.weightsStr {
                    loadState = .loadW
                    continue
                } else if charStr == SaveLoad.biasStr {
                    loadState = .loadB
                    continue
                }
            case .loadW:
                fallthrough
            case .loadB:
                //Parse matrix
                if(!loadMat) {
                    if (charStr == SaveLoad.beginMatrix) {
                        loadMat = true
                        continue
                    }
                } else {
                    if (charStr != SaveLoad.endMatrix) {
                        loadStr += charStr
                        continue
                    } else { //End matrix
                        let mat: Matrix = Matrix.loadFromString(in: loadStr)
                        if (loadState == .loadW) {
                            W.append(mat)
                        } else if (loadState == .loadB) {
                            b.append(mat)
                        }
                        loadStr = ""
                        loadMat = false
                        continue
                    }
                }
            default:
                continue
            }
        }
        return NNModel(W: W, b: b, type: type)
    }
    
}

//For debugging purposes
public extension NNModel{
    
    private func estimate_dAL(X: Matrix, Y: Matrix) -> Matrix {
        let A: [Matrix] = forwardProp(data: X)
        let AL: Matrix = A[A.count-1]
        return estimate_dAL(AL: AL, Y: Y)
    }
    
    private func getScalarHack(AL: Matrix, Y: Matrix, dAL: Matrix) -> Double {
        let epsilon: Double = 0.000001
        let originalNumber = AL.data[0]
        AL.data[0] = originalNumber + epsilon
        let costUpper = computeCost(predictions: AL, labels: Y)
        AL.data[0] = originalNumber - epsilon
        let costLower = computeCost(predictions: AL, labels: Y)
        let correctGradient: Double = ((costUpper - costLower) / (2 * epsilon)) * Double(AL.n)
        let incorrectGradient = dAL.data[0]
        return correctGradient / incorrectGradient
    }
    
    private func estimate_dAL(AL: Matrix, Y: Matrix) -> Matrix {
        let epsilon: Double = 0.000001
        var dAL: Matrix = Matrix.zeroes(rows: AL.m, columns: AL.n)
        for i in 0...(AL.data.count-1) {
            let originalNumber = AL.data[i]
            AL.data[i] = originalNumber + epsilon
            let costUpper = computeCost(predictions: AL, labels: Y)
            AL.data[i] = originalNumber - epsilon
            let costLower = computeCost(predictions: AL, labels: Y)
            dAL.data[i] = (costUpper - costLower) / (2 * epsilon)
            AL.data[i] = originalNumber
        }
        dAL = dAL * Double(AL.n)
        return dAL
    }
    
    private func gradientEstimate(X: Matrix, Y: Matrix) -> Gradients {
        let epsilon: Double = 0.000001
        var dW: [Matrix] = []
        var db: [Matrix] = []
        for weightsLayer: Matrix in W {
            let dWCurrent = Matrix.zeroes(rows: weightsLayer.m, columns: weightsLayer.n)
            for i in 0...(weightsLayer.data.count-1) {
                let originalNumber = weightsLayer.data[i]
                weightsLayer.data[i] = originalNumber + epsilon
                let AUpper: [Matrix] = forwardProp(data: X)
                let costUpper = computeCost(predictions: AUpper[AUpper.count-1], labels: Y)
                weightsLayer.data[i] = originalNumber - epsilon
                let ALower: [Matrix] = forwardProp(data: X)
                let costLower = computeCost(predictions: ALower[ALower.count-1], labels: Y)
                dWCurrent.data[i] = (costUpper - costLower) / (2 * epsilon)
                weightsLayer.data[i] = originalNumber
            }
            dW.append(dWCurrent)
        }
        for biasLayer: Matrix in b {
            let dbCurrent = Matrix.zeroes(rows: biasLayer.m, columns: biasLayer.n)
            for i in 0...(biasLayer.data.count-1) {
                let originalNumber = biasLayer.data[i]
                biasLayer.data[i] = originalNumber + epsilon
                let AUpper: [Matrix] = forwardProp(data: X)
                let costUpper = computeCost(predictions: AUpper[AUpper.count-1], labels: Y)
                biasLayer.data[i] = originalNumber - epsilon
                let ALower: [Matrix] = forwardProp(data: X)
                let costLower = computeCost(predictions: ALower[ALower.count-1], labels: Y)
                dbCurrent.data[i] = (costUpper - costLower) / (2 * epsilon)
                biasLayer.data[i] = originalNumber
            }
            db.append(dbCurrent)
        }
        return Gradients(dW: dW, db: db, dA: [])
    }
    
    public func gradientCheck(X: Matrix, Y: Matrix) {
        let estimates: Gradients = gradientEstimate(X: X, Y: Y)
        let computed: Gradients = backProp(labels: Y, A: forwardProp(data: X))
        print("Checking gradients:")
        for i in 0...(computed.dW.count-1) {
            let dWDiff: Matrix = computed.dW[i] - estimates.dW[i]
            let dbDiff: Matrix = computed.db[i] - estimates.db[i]
            print("    Estimated dW" + i.description + " difference")
            print(dWDiff.stringRepresentation())
            print("    Estimated db" + i.description + " difference")
            print(dbDiff.stringRepresentation())
        }
    }
    
}

//Common activation functions and derivatives
public extension NNModel {
    
    private static let leakyReluConst: Double = 0.01
    
    public static func logistic(z: Double) -> Double {
        return 1.0/(1.0 + exp(-z))
    }
    
    public static func logisticDerivative(z: Double) -> Double {
        return logistic(z: z) * (1 - logistic(z: z))
    }
    
    //When the original value for f(x) is precomputed
    public static func logisticDerivative2(a: Double) -> Double {
        return a * (1 - a)
    }
    
    //tanh already implemented
    
    public static func tanhDerivative(z: Double) -> Double {
        return tanhDerivative2(a: tanh(z))
    }
    
    //When the original value for f(x) is precomputed
    public static func tanhDerivative2(a: Double) -> Double {
        return 1-(a*a)
    }
    
    public static func relu(z: Double) -> Double {
        return max(0.0, z)
    }
    
    public static func reluDerivative(z: Double) -> Double {
        return z >= 0.0 ? 1.0 : 0.0
    }
    
    public static func reluDerivative2(a: Double) -> Double {
        //Pretty much the same thing
        //Slightly different behaviour at a=0
        return reluDerivative(z:a)
        //return a != 0 ? 1.0 : 0.0
    }
    
    public static func leakyRelu(z: Double) -> Double {
        return max(NNModel.leakyReluConst*z, z)
    }
    
    public static func leakyReluDerivative(z: Double) -> Double {
        return z >= 0.0 ? 1.0: NNModel.leakyReluConst
    }
    
}
