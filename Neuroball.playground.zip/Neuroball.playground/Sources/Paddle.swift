import Foundation
import SpriteKit

public class Paddle: SKSpriteNode {
    
    let maxVelocity: CGFloat = CGFloat(600)
    
    public override init(texture tex: SKTexture!, color colour: UIColor, size s: CGSize) {
        super.init(texture: tex, color: colour, size: s)
    }
    
    public required init?(coder decoder: NSCoder) {
        super.init(coder: decoder)
    }
    
    public func movePaddle(direction dir: CGVector) {
        let phys:SKPhysicsBody = physicsBody!
        let normalisedDir = dir.getNormalised()
        phys.velocity = normalisedDir*maxVelocity
    }
    
}

public extension CGVector{
    
    public func getMagnitude() -> CGFloat {
        return sqrt(dx*dx + dy*dy)
    }
    
    public func getNormalised() -> CGVector {
        var dxTemp: CGFloat = dx
        var dyTemp: CGFloat = dy
        let magnitude = getMagnitude()
        dxTemp /= magnitude
        dyTemp /= magnitude
        return CGVector(dx: dxTemp, dy: dyTemp)
    }
    
    static func * (left: CGVector, right: CGFloat) -> CGVector {
        return CGVector(dx: left.dx*right, dy: left.dy*right)
    }
    
    static func * (left: CGFloat, right: CGVector) -> CGVector {
        return right*left
    }
    
    static func + (left: CGVector, right: CGVector) -> CGVector {
        return CGVector(dx: left.dx + right.dx, dy: left.dy+right.dy)
    }
    
    static prefix func - (vector: CGVector) -> CGVector {
        return vector*(-1)
    }
    
    static func - (left: CGVector, right: CGVector) -> CGVector {
        return left+(-right)
    }
    
}
