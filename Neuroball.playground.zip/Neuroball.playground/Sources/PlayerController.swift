import Foundation
import SpriteKit

class PlayerController: Controller {
    
    let stopMovingRadius: CGFloat = CGFloat(12)
    
    public override func getMoveData(sensor gameSensor: Sensor) -> MoveData {
        var shouldMove: Bool = gameSensor.touching
        let direction = CGVector(dx: gameSensor.touchX - gameSensor.selfX, dy: gameSensor.touchY - gameSensor.selfY)
        //Prevents "jumpy" behaviour
        if direction.getMagnitude() < stopMovingRadius {
            shouldMove = false
        }
        return MoveData(direction: direction.getNormalised(), shouldMove: shouldMove, desiredMoveLocation: CGVector(dx: gameSensor.touchX, dy: gameSensor.touchY))
    }
    
}
