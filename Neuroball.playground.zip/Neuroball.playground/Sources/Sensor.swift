import Foundation
import CoreGraphics

public struct Sensor {
    
    let ballX: CGFloat
    let ballY: CGFloat
    let ballVX: CGFloat
    let ballVY: CGFloat
    let ballAngularV: CGFloat
    
    let selfX: CGFloat
    let selfY: CGFloat
    let opponentX: CGFloat
    let opponentY: CGFloat
    
    let touchX: CGFloat
    let touchY: CGFloat
    let touching: Bool
    
    let flippedY: Bool
    
    public init(ballX bx: CGFloat, ballY by: CGFloat, ballVX bvx: CGFloat, ballVY bvy: CGFloat, ballAngularV bav: CGFloat, selfX sx: CGFloat, selfY sy: CGFloat, opponentX ox: CGFloat, opponentY oy: CGFloat, touchX tx: CGFloat, touchY ty: CGFloat, touching t: Bool, flippedY fy: Bool) {
        ballX = bx
        ballVX = bvx
        ballAngularV = bav
        selfX = sx
        opponentX = ox
        touchX = tx
        touching = t
        flippedY = fy
        if (flippedY) {
            ballY = -by
            ballVY = -bvy
            selfY = -sy
            opponentY = -oy
            touchY = -ty
        } else {
            ballY = by
            ballVY = bvy
            selfY = sy
            opponentY = oy
            touchY = ty
        }
        
    }
    
    public init(ballPos bp: CGPoint, ballVel bv: CGVector, ballAngularV bav: CGFloat, selfPos sp: CGPoint, opponentPos op: CGPoint, touchPos tp: CGPoint, touching t: Bool, flippedY fy: Bool){
        self.init(ballX: bp.x, ballY: bp.y, ballVX: bv.dx, ballVY: bv.dy, ballAngularV: bav, selfX: sp.x, selfY: sp.y, opponentX: op.x, opponentY: op.y, touchX: tp.x, touchY: tp.y, touching: t, flippedY: fy)
    }
    
    public init(ball b: Ball, selfPaddle sp: Paddle, opponentPaddle op: Paddle, touchPos tp: CGPoint, touching t: Bool, flippedY fy: Bool) {
        self.init(ballPos: b.position, ballVel: b.phys.velocity, ballAngularV: b.phys.angularVelocity, selfPos: sp.position, opponentPos: op.position, touchPos: tp, touching: t, flippedY: fy)
    }
    
    public func getOpponentSensor() -> Sensor {
        return Sensor(ballX: self.ballX, ballY: self.ballY, ballVX: self.ballVX, ballVY: self.ballVY, ballAngularV: self.ballAngularV, selfX:  self.opponentX, selfY: self.opponentY, opponentX: self.selfX, opponentY: self.selfY, touchX: self.touchX, touchY: self.touchY, touching: self.touching, flippedY: !self.flippedY)
    }
    
    private struct NormValues {
        static let minX: Double = -240.0
        static let maxX: Double = 240.0

        static let middleX: Double = 0.0
        static let minY: Double = -320.0
        static let maxY: Double = 320.0
        static let middleY: Double = 0.0
        static let minBallV: Double = 0.0
        static let maxBallV: Double = 1200.0
        static let minBallAngularV: Double = 0.0
        static let maxBallAngularV: Double = 20.0
    }
    
    
    public func getLabelsVector() -> Matrix {
        let result: Matrix = Matrix.zeroes(rows: DataMinibatch.numEntries, columns: 1)
        /*result[0, 0] = Double(ballX)
         result[1, 0] = Double(ballY)
         result[2, 0] = Double(ballVX)
         result[3, 0] = Double(ballVY)
         result[4, 0] = Double(ballAngularV)
         result[5, 0] = Double(selfX)
         result[6 ,0] = Double(selfY)
         result[7, 0] = Double(opponentX)
         result[8, 0] = Double(opponentY)*/
        result[0, 0] = Double(ballX)
        result[1, 0] = Double(ballY)
        /*result[0, 0] = Double.ilerp(min: NormValues.minX, max: NormValues.maxX, value: Double(ballX))
        result[1, 0] = Double.ilerp(min: NormValues.minY, max: NormValues.maxY, value: Double(ballY))
        result[2, 0] = Double.ilerp(min: NormValues.minBallV, max: NormValues.maxBallV, value: Double(ballVX))
        result[3, 0] = Double.ilerp(min: NormValues.minBallV, max: NormValues.maxBallV, value: Double(ballVY))
        result[4, 0] = Double.ilerp(min: NormValues.minBallAngularV, max: NormValues.maxBallAngularV, value: Double(ballAngularV))
        result[5, 0] = Double.ilerp(min: NormValues.minX, max: NormValues.maxX, value: Double(selfX))
        result[6 ,0] = Double.ilerp(min: NormValues.minY, max: NormValues.middleY, value: Double(selfY))
        result[7, 0] = Double.ilerp(min: NormValues.minX, max: NormValues.maxX, value: Double(opponentX))
        result[8, 0] = Double.ilerp(min: NormValues.middleY, max: NormValues.maxY, value: Double(opponentY))*/
        return result
    }
    
}

public extension Double {
    public static func lerp(min minimum: Double, max maximum: Double, alpha a: Double) -> Double {
        let magnitude = maximum - minimum
        return magnitude*a + minimum
    }
    
    public static func ilerp(min minimum: Double, max maximum: Double, value v: Double) -> Double {
        return (v-minimum)/(maximum-minimum)
    }
}
