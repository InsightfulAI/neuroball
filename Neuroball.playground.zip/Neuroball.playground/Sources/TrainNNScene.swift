import Foundation
import SpriteKit

public class TrainNNScene: SKScene {
    
    private let learningRate: Double = 0.000001
    //private let trainIter: Int = 1000
    private let doneText: String = "Done!"
    
    private var X: Matrix = Matrix.zeroes(rows: 1, columns: 1)
    private var Y: Matrix = Matrix.zeroes(rows: 1, columns: 1)
    
    private var text: SKLabelNode = SKLabelNode()
    
    private var buttons: [Button] = []
    
    private var moveModel: NNModel = NNModel.init(layerSizes: [DataMinibatch.numEntries, 20, 20, DataMinibatch.numLabelsMove], type: NNModel.NNType.regressor)
    
    private var trainIndex = 0
    
    private var done: Bool = false
    
    public override func sceneDidLoad() {
        text = childNode(withName: "text") as! SKLabelNode
        X = GameData.instance.mlData.minibatches[0].data
        Y = GameData.instance.mlData.minibatches[0].labelsMove
        for i in 1...(GameData.instance.mlData.index - 2) {
            X = Matrix.appendHorizontal(left: X, right: GameData.instance.mlData.minibatches[i].data)
            Y = Matrix.appendHorizontal(left: Y, right: GameData.instance.mlData.minibatches[i].labelsMove)
        }
        print(X.n.description + "Training examples")
        let playButton: Button = childNode(withName: "playNN") as! Button
        playButton.addAction(action: playNN)
        buttons.append(playButton)
        let homeButton: Button = childNode(withName: "home") as! Button
        if (GameData.instance.tutorial) {
            homeButton.removeFromParent()
        } else {
            homeButton.addAction(action: home)
            buttons.append(homeButton)
        }
        for button: Button in buttons {
            button.disable()
        }
    }
    
    public override func update(_ currentTime: TimeInterval) {
        for _ in 1...10 { //number of  iterations per frame
            if trainIndex >= GameData.instance.nnIter {
                trainingDone()
                return
            }
            let _ = moveModel.trainGradientDescent(data: X, labels: Y, learningRate: learningRate)
            trainIndex += 1
        }
        text.text = String(format: "%.1f", Double(trainIndex) / Double(GameData.instance.nnIter) * Double(100)) + "%"
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t: UITouch in touches {
            for button: Button in buttons {
                _ = button.checkClick(pointer: t.location(in: self))
            }
        }
    }
    
    private func trainingDone() {
        if done {
            return
        }
        for button: Button in buttons {
            button.enable()
        }
        text.text = doneText
        GameData.instance.aiModel = moveModel.stringRepresentation()
        GameData.instance.numModelsTrained += 1
        GameData.instance.neuralNetworks.models.append(GameData.instance.aiModel)
        GameData.instance.neuralNetworks.names.append(GameData.instance.name + GameData.instance.numModelsTrained.description)
        done = true
    }
    
    private func playNN() {
        GameData.instance.isBot = false
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = GameScene(fileNamed: "GameScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
    
    private func home() {
        let transition: SKTransition = SKTransition.crossFade(withDuration: 1.0)
        let scene = HomeScene(fileNamed: "HomeScene.sks")!
        self.view?.presentScene(scene, transition: transition)
    }
    
}
